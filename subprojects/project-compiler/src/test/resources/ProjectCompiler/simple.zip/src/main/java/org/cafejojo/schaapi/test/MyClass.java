package org.cafejojo.schaapi.test;

public class MyClass {
    public String foo() {
        return "bar";
    }
}
